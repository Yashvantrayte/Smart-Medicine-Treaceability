package com.blockchain.api;


import com.blockchain.Models.BlockModel;
import com.blockchain.Models.MedicineModel;
import com.blockchain.Models.ResultModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;



public interface APIService {

    @FormUrlEncoded
    @POST("BlockChain/login.php")
    Call<ResultModel> userLogin(
            @Field("email") String email,
            @Field("password") String password,
            @Field("role") String role
    );

    @FormUrlEncoded
    @POST("BlockChain/createBlock0.php")
    Call<ResultModel> createBlock0(
            @Field("mid") String mid,
            @Field("data") String data,
            @Field("previousHash") String previousHash,
            @Field("myhash") String myhash
    );

    @FormUrlEncoded
    @POST("BlockChain/createBlock1.php")
    Call<ResultModel> createBlock1(
            @Field("mid") String mid,
            @Field("data") String data,
            @Field("previousHash") String previousHash,
            @Field("myhash") String myhash
    );

    @FormUrlEncoded
    @POST("BlockChain/createBlock2.php")
    Call<ResultModel> createBlock2(
                    @Field("mid") String mid,
                    @Field("data") String data,
                    @Field("previousHash") String previousHash,
                    @Field("myhash") String myhash
            );
    @FormUrlEncoded
    @POST("BlockChain/createBlock3.php")
    Call<ResultModel> createBlock3(
            @Field("mid") String mid,
            @Field("data") String data,
            @Field("previousHash") String previousHash,
            @Field("myhash") String myhash
    );

    @FormUrlEncoded
    @POST("BlockChain/getBlock0.php")
    Call<BlockModel> getBlock0(
            @Field("mid") String mid
    );

    @FormUrlEncoded
    @POST("BlockChain/getBlock1.php")
    Call<BlockModel> getBlock1(
            @Field("mid") String mid
    );

    @FormUrlEncoded
    @POST("BlockChain/getAllBlock.php")
    Call<BlockModel> getAllBlock(
            @Field("mid") String mid
    );

    @FormUrlEncoded
    @POST("BlockChain/getmedicine.php")
    Call<MedicineModel> getmedicine(
            @Field("mid") String mid
    );

    @FormUrlEncoded
    @POST("BlockChain/updatemedicine.php")
    Call<MedicineModel> updatemedicine(
            @Field("mid") String mid
    );

    @FormUrlEncoded
    @POST("BlockChain/getBlock2.php")
    Call<BlockModel> getBlock2(
            @Field("mid") String mid
    );
    @FormUrlEncoded
        @POST("BlockChain/getBlock3.php")
        Call<BlockModel> getBlock3(
                @Field("mid") String mid
        );

}

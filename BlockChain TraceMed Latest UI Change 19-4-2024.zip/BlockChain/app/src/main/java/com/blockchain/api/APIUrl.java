package com.blockchain.api;



public class APIUrl {
    public static final String BASE_URL = "http://192.168.43.37/";
}

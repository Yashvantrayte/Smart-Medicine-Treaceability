package com.blockchain;

import android.Manifest;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

import com.blockchain.Company.CompanyLogin;
import com.blockchain.Dealer.DealerLogin;
import com.blockchain.Distributer.DistributerLogin;
import com.blockchain.Medical.MedicalLogin;
import com.blockchain.User.ShowAllBlock;
import com.blockchain.User.UserHome;
import com.nabinbhandari.android.permissions.PermissionHandler;
import com.nabinbhandari.android.permissions.Permissions;


public class UserType extends AppCompatActivity {

    CardView btnuser,btncompany,btndistributer,btndealer,btnmedical;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_type);

        String[] permissions = {Manifest.permission.CAMERA};
        Permissions.check(this/*context*/, permissions, null/*rationale*/, null/*options*/, new PermissionHandler() {
            @Override
            public void onGranted() {
                // do your task.
            }
        });

        btnuser = (CardView)findViewById(R.id.btnuser);
        btncompany = (CardView)findViewById(R.id.btncompany);
        btndistributer = (CardView)findViewById(R.id.btndistributer);
        btndealer = (CardView)findViewById(R.id.btndealer);
        btnmedical = (CardView)findViewById(R.id.btnmedical);

        btnuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), UserHome.class));
            }
        });
        btncompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), CompanyLogin.class));
            }
        });
        btndistributer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), DistributerLogin.class));
            }
        });
        btndealer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), DealerLogin.class));
            }
        });
        btnmedical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MedicalLogin.class));
            }
        });

    }
}

package com.blockchain.Distributer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.blockchain.Dealer.DealerHome;
import com.blockchain.Dealer.DealerLogin;
import com.blockchain.Models.ResultModel;
import com.blockchain.R;
import com.blockchain.api.APIService;
import com.blockchain.api.APIUrl;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DistributerLogin extends AppCompatActivity {
    EditText edtemail,edtpass;
    Button btnlogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distributer_login);

        edtemail= (EditText) findViewById(R.id.edtemail);
        edtpass= (EditText) findViewById(R.id.edtpass);
        btnlogin= (Button)findViewById(R.id.btnlogin);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edtemail.getText().toString();
                String pass = edtpass.getText().toString();
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass))
                {
                    Toast.makeText(DistributerLogin.this, "Please fill data properly", Toast.LENGTH_SHORT).show();
                }
                else {
                    loginProcess(email, pass);
                }
            }
        });
    }

    private void loginProcess(String email, String pass) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<ResultModel> call = api.userLogin(email,pass,"distributor");

        call.enqueue(new Callback<ResultModel>() {
            @Override
            public void onResponse(Call<ResultModel> call, retrofit2.Response<ResultModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                ResultModel resp = response.body();
                Toast.makeText(DistributerLogin.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(DistributerLogin.this, "Login Success..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
                        Intent i = new Intent(getApplicationContext(), DistributerHome.class);
                        startActivity(i);
                        finish();
                    } else {
                        Toast.makeText(DistributerLogin.this, "Wrong Credentials", Toast.LENGTH_SHORT).show();

//                    Log.e(TAG,"Somthing went wrong" +response);

                    }
                }else{Toast.makeText(DistributerLogin.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<ResultModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(DistributerLogin.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

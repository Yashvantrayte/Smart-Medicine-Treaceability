package com.blockchain.Models;

import java.io.Serializable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BlockModel implements Serializable
{

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("message1")
    @Expose
    private String message1;
    @SerializedName("message2")
    @Expose
    private String message2;
    @SerializedName("message3")
    @Expose
    private String message3;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("mid")
    @Expose
    private String mid;
    @SerializedName("data")
    @Expose
    private String data;
    @SerializedName("hash")
    @Expose
    private String hash;
    @SerializedName("previousHash")
    @Expose
    private String previousHash;
    @SerializedName("timeStamp")
    @Expose
    private String timeStamp;
    private final static long serialVersionUID = 543509576881875909L;



    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage1() {
        return message1;
    }

    public void setMessage1(String message1) {
        this.message1 = message1;
    }

    public String getMessage2() {
        return message2;
    }

    public void setMessage2(String message2) {
        this.message2 = message2;
    }

    public String getMessage3() {
        return message3;
    }

    public void setMessage3(String message3) {
        this.message3 = message3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getPreviousHash() {
        return previousHash;
    }

    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

}

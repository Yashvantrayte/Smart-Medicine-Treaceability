package com.blockchain.Dealer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.blockchain.Company.ScanQR0;
import com.blockchain.Distributer.DistributerHome;
import com.blockchain.Models.Block;
import com.blockchain.Models.BlockModel;
import com.blockchain.Models.ResultModel;
import com.blockchain.R;
import com.blockchain.ScanQRAll;
import com.blockchain.api.APIService;
import com.blockchain.api.APIUrl;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DealerHome extends AppCompatActivity {
    CardView btnscanqr,btnshowchain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dealer_home);

        btnscanqr = (CardView) findViewById(R.id.btnscanqr);
        btnshowchain = (CardView) findViewById(R.id.btnshowchain);
        btnshowchain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ScanQRAll.class).putExtra("from","dealer"));
            }
        });
        btnscanqr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ScanQR2.class));
            }
        });

//        getPrevious();

    }

    private void getPrevious() {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<BlockModel> call = api.getBlock1("1");

        call.enqueue(new Callback<BlockModel>() {
            @Override
            public void onResponse(Call<BlockModel> call, retrofit2.Response<BlockModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                BlockModel resp = response.body();
                Toast.makeText(DealerHome.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(DealerHome.this, "Login Success..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        String prevhash = resp.getHash();
                        Block thirdblock = new Block("Yo im the third block",prevhash);
                        System.out.println("Hash for block 3 : " + thirdblock.hash);
                        AddNewBlock("third block",prevhash,thirdblock.hash);
                    } else {
                        Toast.makeText(DealerHome.this, "Wrong Credentials", Toast.LENGTH_SHORT).show();

//                    Log.e(TAG,"Somthing went wrong" +response);

                    }
                }else{Toast.makeText(DealerHome.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<BlockModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(DealerHome.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void AddNewBlock(String data, String previousHash, String myhash){
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("Please wait..");
        progressDialog.show();


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<ResultModel> call = api.createBlock2("1",data,previousHash,myhash);

        call.enqueue(new Callback<ResultModel>() {
            @Override
            public void onResponse(Call<ResultModel> call, Response<ResultModel> response) {
                ResultModel resp = response.body();
                Toast.makeText(DealerHome.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if(resp.getMessage().equals("success")){
                    finish();
                    Toast.makeText(DealerHome.this, "Success!", Toast.LENGTH_SHORT).show();
                }
                else if(resp.getMessage().equals("failure")){
                    Toast.makeText(DealerHome.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                }else if(resp.getMessage().equals("user already exist"))
                {
                    Toast.makeText(DealerHome.this, "Already created", Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<ResultModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(DealerHome.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
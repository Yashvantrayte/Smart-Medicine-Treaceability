package com.blockchain.Company;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.blockchain.Models.Block;
import com.blockchain.Models.ResultModel;
import com.blockchain.R;
import com.blockchain.ScanQRAll;
import com.blockchain.api.APIService;
import com.blockchain.api.APIUrl;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CompanyHome extends AppCompatActivity {
    public static ArrayList<Block> blockchain = new ArrayList<Block>();
    public static int difficulty = 5;
    String myhash;
    CardView btnscanqr,btnshowchain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_home);

        btnscanqr = (CardView) findViewById(R.id.btnscanqr);
        btnshowchain = (CardView) findViewById(R.id.btnshowchain);

        btnscanqr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ScanQR0.class));
            }
        });

        btnshowchain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ScanQRAll.class).putExtra("from","company"));
            }
        });
//        Block genesisBlock = new Block("Hi im the first block", "0");
//        System.out.println("Hash for block 1 : " + genesisBlock.hash);
//        myhash = genesisBlock.hash;
        //AddNewBlock("first block","0",myhash);

//        System.out.println("\nBlockchain is Valid: " + isChainValid());
//
//        String blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(blockchain);
//        System.out.println("\nThe block chain: ");
//        System.out.println(blockchainJson);
    }

    private void AddNewBlock(String data, String previousHash, String myhash){
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("Please wait..");
        progressDialog.show();


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<ResultModel> call = api.createBlock0("1",data,previousHash,myhash);

        call.enqueue(new Callback<ResultModel>() {
            @Override
            public void onResponse(Call<ResultModel> call, Response<ResultModel> response) {
                ResultModel resp = response.body();
                Toast.makeText(CompanyHome.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if(resp.getMessage().equals("success")){
                    finish();
                    Toast.makeText(CompanyHome.this, "Success!", Toast.LENGTH_SHORT).show();
                }
                else if(resp.getMessage().equals("failure")){
                    Toast.makeText(CompanyHome.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                }else if(resp.getMessage().equals("user already exist"))
                {
                    Toast.makeText(CompanyHome.this, "Already created", Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<ResultModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(CompanyHome.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
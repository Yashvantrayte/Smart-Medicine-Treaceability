package com.blockchain.Distributer;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.blockchain.Company.ShowMyBlock0;
import com.blockchain.Models.Block;
import com.blockchain.Models.BlockModel;
import com.blockchain.Models.MedicineModel;
import com.blockchain.Models.ResultModel;
import com.blockchain.R;
import com.blockchain.api.APIService;
import com.blockchain.api.APIUrl;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ShowMyBlock1 extends AppCompatActivity {
    TextView txthash,txtdata,txtprehash;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_my_block1);
        Intent intent = getIntent();

        txthash = (TextView)findViewById(R.id.txthash);
        txtdata = (TextView)findViewById(R.id.txtdata);
        txtprehash = (TextView)findViewById(R.id.txtprehash);

        getMedicine(intent.getExtras().getString("mid"));
    }

    private void getMedicine(String mid) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<MedicineModel> call = api.getmedicine(mid);

        call.enqueue(new Callback<MedicineModel>() {
            @Override
            public void onResponse(Call<MedicineModel> call, retrofit2.Response<MedicineModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                MedicineModel resp = response.body();
                Toast.makeText(ShowMyBlock1.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(ShowMyBlock1.this, "Valid item..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txtdata.setText("batch no : "+resp.getBatchno()+"\nName : "+resp.getName()+"\nPrice : "+resp.getPrice());

                        getPrevious(resp.getId());
                    } else {
                        Toast.makeText(ShowMyBlock1.this, "Invalid item !", Toast.LENGTH_SHORT).show();
                        new AlertDialog.Builder(ShowMyBlock1.this)
                                .setTitle(getResources().getString(R.string.app_name))
                                .setMessage("The item you have scanned is not valid with our system !")
                                .setCancelable(false)
                                .setNegativeButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        finish();
                                    }
                                }).show();
//                    Log.e(TAG,"Somthing went wrong" +response);

                    }
                }else{Toast.makeText(ShowMyBlock1.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<MedicineModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(ShowMyBlock1.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getPrevious(final String mid) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<BlockModel> call = api.getBlock0(mid);

        call.enqueue(new Callback<BlockModel>() {
            @Override
            public void onResponse(Call<BlockModel> call, retrofit2.Response<BlockModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                BlockModel resp = response.body();
                Toast.makeText(ShowMyBlock1.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(ShowMyBlock1.this, "Valid chain..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        String prevhash = resp.getHash();
                        Block secondBlock = new Block("Yo im the second block",prevhash);
                        System.out.println("Hash for block 2 : " + secondBlock.hash);
                        AddNewBlock(mid,"second block",prevhash,secondBlock.hash);
                    } else {
                        Toast.makeText(ShowMyBlock1.this, "Invalid chain", Toast.LENGTH_SHORT).show();
                        new AlertDialog.Builder(ShowMyBlock1.this)
                                .setTitle(getResources().getString(R.string.app_name))
                                .setMessage("The chain is not valid !")
                                .setCancelable(false)
                                .setNegativeButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        finish();
                                    }
                                }).show();
//                    Log.e(TAG,"Somthing went wrong" +response);

                    }
                }else{Toast.makeText(ShowMyBlock1.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<BlockModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(ShowMyBlock1.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void AddNewBlock(String mid, String data, final String previousHash, final String myhash){
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("Please wait..");
        progressDialog.show();


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<ResultModel> call = api.createBlock1(mid,data,previousHash,myhash);

        call.enqueue(new Callback<ResultModel>() {
            @Override
            public void onResponse(Call<ResultModel> call, Response<ResultModel> response) {
                ResultModel resp = response.body();
                Toast.makeText(ShowMyBlock1.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if(resp.getMessage().equals("success")){
                    txthash.setText(myhash);
                    txtprehash.setText(previousHash);
                    Toast.makeText(ShowMyBlock1.this, "Block Created !", Toast.LENGTH_SHORT).show();
                }
                else if(resp.getMessage().equals("failure")){
                    Toast.makeText(ShowMyBlock1.this, "Failed to create block !", Toast.LENGTH_SHORT).show();
                    new AlertDialog.Builder(ShowMyBlock1.this)
                            .setTitle(getResources().getString(R.string.app_name))
                            .setMessage("Failed to create new block !")
                            .setCancelable(false)
                            .setNegativeButton("ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                }
                            }).show();
                }else if(resp.getMessage().equals("user already exist"))
                {
                    new AlertDialog.Builder(ShowMyBlock1.this)
                            .setTitle(getResources().getString(R.string.app_name))
                            .setMessage("Block is created already !")
                            .setCancelable(false)
                            .setNegativeButton("ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                }
                            }).show();
                    Toast.makeText(ShowMyBlock1.this, "Block is created already ", Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<ResultModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(ShowMyBlock1.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

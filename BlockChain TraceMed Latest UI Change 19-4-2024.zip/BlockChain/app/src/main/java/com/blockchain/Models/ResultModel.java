package com.blockchain.Models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ResultModel implements Serializable {

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("medicalname")
    @Expose
    private String medicalname;
    @SerializedName("ownername")
    @Expose
    private String ownername;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("licenceno")
    @Expose
    private String licenceno;
    @SerializedName("address")
    @Expose
    private String address;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("cid")
    @Expose
    private String cid;
    @SerializedName("did")
    @Expose
    private String did;
    @SerializedName("dlid")
    @Expose
    private String dlid;

    @SerializedName("cname")
    @Expose
    private String cname;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("dname")
    @Expose
    private String dname;


    public ResultModel() {
    }

    public ResultModel(String message, String id, String medicalname, String ownername, String email, String mobile, String licenceno, String address, String password, String cid, String did, String dlid, String cname, String name, String dname) {
        this.message = message;
        this.id = id;
        this.medicalname = medicalname;
        this.ownername = ownername;
        this.email = email;
        this.mobile = mobile;
        this.licenceno = licenceno;
        this.address = address;
        this.password = password;
        this.cid = cid;
        this.did = did;
        this.dlid = dlid;
        this.cname = cname;
        this.name = name;
        this.dname = dname;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMedicalname() {
        return medicalname;
    }

    public void setMedicalname(String medicalname) {
        this.medicalname = medicalname;
    }

    public String getOwnername() {
        return ownername;
    }

    public void setOwnername(String ownername) {
        this.ownername = ownername;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getLicenceno() {
        return licenceno;
    }

    public void setLicenceno(String licenceno) {
        this.licenceno = licenceno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getDid() {
        return did;
    }

    public void setDid(String did) {
        this.did = did;
    }

    public String getDlid() {
        return dlid;
    }

    public void setDlid(String dlid) {
        this.dlid = dlid;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }
}
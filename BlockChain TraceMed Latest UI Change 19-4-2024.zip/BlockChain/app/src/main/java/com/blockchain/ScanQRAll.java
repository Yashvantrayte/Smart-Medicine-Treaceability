package com.blockchain;

import android.content.Intent;
import android.graphics.PointF;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import android.widget.Toast;

import com.blockchain.Company.ShowMyBlock0;
import com.blockchain.User.ShowAllBlock;
import com.dlazaro66.qrcodereaderview.QRCodeReaderView;

public class ScanQRAll extends AppCompatActivity implements QRCodeReaderView.OnQRCodeReadListener{
    private TextView resultTextView;
    private QRCodeReaderView qrCodeReaderView;
    //    private CodeScanner mCodeScanner;
    String from;
    SharedSpace sharedSpace;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_qrall);
        qrCodeReaderView = (QRCodeReaderView) findViewById(R.id.qrdecoderview);
        qrCodeReaderView.setOnQRCodeReadListener(this);
        // Use this function to enable/disable decoding
        qrCodeReaderView.setQRDecodingEnabled(true);
        // Use this function to change the autofocus interval (default is 5 secs)
        qrCodeReaderView.setAutofocusInterval(5000L);
        // Use this function to enable/disable Torch
        qrCodeReaderView.setTorchEnabled(true);
        // Use this function to set front camera preview
        qrCodeReaderView.setFrontCamera();
        // Use this function to set back camera preview
        qrCodeReaderView.setBackCamera();

        Intent intent = getIntent();
        from = intent.getExtras().getString("from");
    }

    // Called when a QR is decoded
    // "text" : the text encoded in QR
    // "points" : points where QR control points are placed in View
    @Override
    public void onQRCodeRead(String text, PointF[] points) {
        // FORMATE EX : mid : 1,jgf : wdc,edc;
        // resultTextView.setText(text);
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
        String[] data = text.split(",", 2);
        String middata = data[0];
        String[] data2 = middata.split(":", 2);
        System.out.println("mid = "+data2[1]); //Pankaj
        String mid = data2[1];
        Toast.makeText(this, "mid : "+mid, Toast.LENGTH_SHORT).show();

        if (!TextUtils.isEmpty(mid)){
            startActivity(new Intent(getApplicationContext(), ShowAllBlock.class).putExtra("mid",mid).putExtra("from",from));
            finish();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        qrCodeReaderView.startCamera();
    }

    @Override
    protected void onPause() {
        super.onPause();
        qrCodeReaderView.stopCamera();
    }
}
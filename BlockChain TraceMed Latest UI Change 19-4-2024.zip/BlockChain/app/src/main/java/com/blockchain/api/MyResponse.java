package com.blockchain.api;



public class MyResponse {
   public boolean error;
    String message;
}

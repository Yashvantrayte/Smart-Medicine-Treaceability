package com.blockchain.Models;


import java.io.Serializable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MedicineModel implements Serializable
{

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("cid")
    @Expose
    private String cid;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("batchno")
    @Expose
    private String batchno;
    @SerializedName("price")
    @Expose
    private String price;
    @SerializedName("quantity")
    @Expose
    private String quantity;


    @SerializedName("mfgdate")
    @Expose
    private String mfgdate;
    @SerializedName("expdate")
    @Expose
    private String expdate;
    @SerializedName("generic_name")
    @Expose
    private String generic_name;
    @SerializedName("type")
    @Expose
    private String type;

    private final static long serialVersionUID = -5605934903081346635L;

    /**
     * No args constructor for use in serialization
     *
     */
    public MedicineModel() {
    }

    /**
     *
     * @param id
     * @param message
     * @param price
     * @param batchno
     * @param name
     * @param quantity
     * @param cid
     */
    public MedicineModel(String message, String id, String cid, String name, String batchno, String price, String quantity, String mfgdate, String expdate, String generic_name, String type) {
        super();
        this.message = message;
        this.id = id;
        this.cid = cid;
        this.name = name;
        this.batchno = batchno;
        this.price = price;
        this.quantity = quantity;
        this.mfgdate = mfgdate;
        this.expdate = expdate;
        this.generic_name = generic_name;
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBatchno() {
        return batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }


    public String getMfgdate() {
        return mfgdate;
    }

    public void setMfgdate(String mfgdate) {
        this.mfgdate = mfgdate;
    }

    public String getExpdate() {
        return expdate;
    }

    public void setExpdate(String expdate) {
        this.expdate = expdate;
    }

    public String getGeneric_name() {
        return generic_name;
    }

    public void setGeneric_name(String generic_name) {
        this.generic_name = generic_name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

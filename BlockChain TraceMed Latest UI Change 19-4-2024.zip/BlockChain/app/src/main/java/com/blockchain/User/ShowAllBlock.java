package com.blockchain.User;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.blockchain.Dealer.ShowMyBlock2;
import com.blockchain.Distributer.ShowMyBlock1;
import com.blockchain.Medical.ShowMyBlock3;
import com.blockchain.Models.Block;
import com.blockchain.Models.BlockModel;
import com.blockchain.Models.MedicineModel;
import com.blockchain.R;
import com.blockchain.api.APIService;
import com.blockchain.api.APIUrl;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ShowAllBlock extends AppCompatActivity {
    TextView txthash,txtdata,txtprehash;
    TextView txthash1,txtdata1,txtprehash1;
    TextView txthash2,txtdata2,txtprehash2;
    TextView txthash3,txtdata3,txtprehash3;
    String from;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all_block);

        txthash = (TextView)findViewById(R.id.txthash);
        txtdata = (TextView)findViewById(R.id.txtdata);
        txtprehash = (TextView)findViewById(R.id.txtprehash);

        txthash1 = (TextView)findViewById(R.id.txthash1);
        txtdata1 = (TextView)findViewById(R.id.txtdata1);
        txtprehash1 = (TextView)findViewById(R.id.txtprehash1);

        txthash2 = (TextView)findViewById(R.id.txthash2);
        txtdata2 = (TextView)findViewById(R.id.txtdata2);
        txtprehash2 = (TextView)findViewById(R.id.txtprehash2);

        txthash3 = (TextView)findViewById(R.id.txthash3);
        txtdata3 = (TextView)findViewById(R.id.txtdata3);
        txtprehash3 = (TextView)findViewById(R.id.txtprehash3);

        Intent intent = getIntent();
        from = intent.getExtras().getString("from");
        getMedicine(intent.getExtras().getString("mid"));
    }

    private void getMedicine(String mid) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<MedicineModel> call = api.getmedicine(mid);

        call.enqueue(new Callback<MedicineModel>() {
            @Override
            public void onResponse(Call<MedicineModel> call, retrofit2.Response<MedicineModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                MedicineModel resp = response.body();
                Toast.makeText(ShowAllBlock.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(ShowAllBlock.this, "Valid item..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txtdata.setText("batch no : "+resp.getBatchno()+"\nName : "+resp.getName()+"\nPrice : "+resp.getPrice()+"\nMfgDate : "+resp.getMfgdate()+"\nExpDate : "+resp.getExpdate()+"\nGeneric Name : "+resp.getGeneric_name()+"\nType : "+resp.getType());
                        txtdata1.setText("batch no : "+resp.getBatchno()+"\nName : "+resp.getName()+"\nPrice : "+resp.getPrice()+"\nMfgDate : "+resp.getMfgdate()+"\nExpDate : "+resp.getExpdate()+"\nGeneric Name : "+resp.getGeneric_name()+"\nType : "+resp.getType());
                        txtdata2.setText("batch no : "+resp.getBatchno()+"\nName : "+resp.getName()+"\nPrice : "+resp.getPrice()+"\nMfgDate : "+resp.getMfgdate()+"\nExpDate : "+resp.getExpdate()+"\nGeneric Name : "+resp.getGeneric_name()+"\nType : "+resp.getType());
                        txtdata3.setText("batch no : "+resp.getBatchno()+"\nName : "+resp.getName()+"\nPrice : "+resp.getPrice()+"\nMfgDate : "+resp.getMfgdate()+"\nExpDate : "+resp.getExpdate()+"\nGeneric Name : "+resp.getGeneric_name()+"\nType : "+resp.getType());

                        getPrevious(resp.getId());
                        getPrevious1(resp.getId());
                        getPrevious2(resp.getId());
                        getPrevious3(resp.getId());
                    } else {
                        Toast.makeText(ShowAllBlock.this, "Invalid item !", Toast.LENGTH_SHORT).show();
                        new AlertDialog.Builder(ShowAllBlock.this)
                                .setTitle(getResources().getString(R.string.app_name))
                                .setMessage("The item you have scanned is not valid with our system !")
                                .setCancelable(false)
                                .setNegativeButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        finish();
                                    }
                                }).show();
//                    Log.e(TAG,"Somthing went wrong" +response);

                    }
                }else{Toast.makeText(ShowAllBlock.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<MedicineModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(ShowAllBlock.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getAll(final String mid) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson)) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<BlockModel> call = api.getAllBlock(mid);

        call.enqueue(new Callback<BlockModel>() {
            @Override
            public void onResponse(Call<BlockModel> call, retrofit2.Response<BlockModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                BlockModel resp = response.body();
                Toast.makeText(ShowAllBlock.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("first")) {
                        Toast.makeText(ShowAllBlock.this, "Valid chain..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txthash.setText(resp.getHash());
                        txtprehash.setText(resp.getPreviousHash());
                    } else if (resp.getMessage().equals("second")) {
                        Toast.makeText(ShowAllBlock.this, "Valid chain..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txthash1.setText(resp.getHash());
                        txtprehash1.setText(resp.getPreviousHash());
                    }else if (resp.getMessage().equals("third")) {
                        Toast.makeText(ShowAllBlock.this, "Valid chain..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txthash2.setText(resp.getHash());
                        txtprehash2.setText(resp.getPreviousHash());
                    }else if (resp.getMessage().equals("fourth")) {
                        Toast.makeText(ShowAllBlock.this, "Valid chain..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txthash3.setText(resp.getHash());
                        txtprehash3.setText(resp.getPreviousHash());
                    }
                }
                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<BlockModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed  "+t.getLocalizedMessage());
                Toast.makeText(ShowAllBlock.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getPrevious(final String mid) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<BlockModel> call = api.getBlock0(mid);

        call.enqueue(new Callback<BlockModel>() {
            @Override
            public void onResponse(Call<BlockModel> call, retrofit2.Response<BlockModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                BlockModel resp = response.body();
                Toast.makeText(ShowAllBlock.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(ShowAllBlock.this, "Valid chain..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txtdata.setText(txtdata.getText()+"\nTimestamp : "+resp.getTimeStamp());
                        txthash.setText(resp.getHash());
                        txtprehash.setText(resp.getPreviousHash());
                    }
                }else{Toast.makeText(ShowAllBlock.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<BlockModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(ShowAllBlock.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getPrevious1(final String id) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<BlockModel> call = api.getBlock1(id);

        call.enqueue(new Callback<BlockModel>() {
            @Override
            public void onResponse(Call<BlockModel> call, retrofit2.Response<BlockModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                BlockModel resp = response.body();
                Toast.makeText(ShowAllBlock.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(ShowAllBlock.this, "Valid chain..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txtdata1.setText(txtdata1.getText()+"\nTimestamp : "+resp.getTimeStamp());
                        txthash1.setText(resp.getHash());
                        txtprehash1.setText(resp.getPreviousHash());
                    }
                }else{Toast.makeText(ShowAllBlock.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<BlockModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(ShowAllBlock.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getPrevious2(final String mid) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<BlockModel> call = api.getBlock2(mid);

        call.enqueue(new Callback<BlockModel>() {
            @Override
            public void onResponse(Call<BlockModel> call, retrofit2.Response<BlockModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                BlockModel resp = response.body();
                Toast.makeText(ShowAllBlock.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(ShowAllBlock.this, "Valid chain..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txtdata2.setText(txtdata2.getText()+"\nTimestamp : "+resp.getTimeStamp());
                        txthash2.setText(resp.getHash());
                        txtprehash2.setText(resp.getPreviousHash());
                    }
                }else{Toast.makeText(ShowAllBlock.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<BlockModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(ShowAllBlock.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getPrevious3(final String mid) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<BlockModel> call = api.getBlock3(mid);

        call.enqueue(new Callback<BlockModel>() {
            @Override
            public void onResponse(Call<BlockModel> call, retrofit2.Response<BlockModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                BlockModel resp = response.body();
                Toast.makeText(ShowAllBlock.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(ShowAllBlock.this, "Valid chain..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        txtdata3.setText(txtdata3.getText()+"\nTimestamp : "+resp.getTimeStamp());
                        txthash3.setText(resp.getHash());
                        txtprehash3.setText(resp.getPreviousHash());

                        if (from.equals("user")){
                            updatemedicine(mid);
                        }
                    }
                }else{Toast.makeText(ShowAllBlock.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<BlockModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(ShowAllBlock.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updatemedicine(String mid) {
        final ProgressDialog progressDialog =  new ProgressDialog(this);
        progressDialog.setMessage("please wait..");
        progressDialog.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(APIUrl.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        APIService api = retrofit.create(APIService.class);

        Call<MedicineModel> call = api.updatemedicine(mid);

        call.enqueue(new Callback<MedicineModel>() {
            @Override
            public void onResponse(Call<MedicineModel> call, retrofit2.Response<MedicineModel> response) {
                String TAG = "errrrorrrrrrrrrrr";
                MedicineModel resp = response.body();
                Toast.makeText(ShowAllBlock.this, resp.getMessage(), Toast.LENGTH_SHORT).show();

                if (resp != null) {
                    if (resp.getMessage().equals("success")) {
                        Toast.makeText(ShowAllBlock.this, "Valid item..", Toast.LENGTH_SHORT).show();
//                        sharedSpace.putData("loginstatus","true");
//                        sharedSpace.putData("uid",resp.getUid());
//                        sharedSpace.putData("email",resp.getEmail());
//                        Intent i = new Intent(getApplicationContext(), CompanyHome.class);
//                        startActivity(i);
//                        finish();
                        Toast.makeText(ShowAllBlock.this, "Success !", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(ShowAllBlock.this, "failed to update !", Toast.LENGTH_SHORT).show();

//                    Log.e(TAG,"Somthing went wrong" +response);

                    }
                }else{Toast.makeText(ShowAllBlock.this, "Email not register please contact admin", Toast.LENGTH_SHORT).show();}

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<MedicineModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                Log.d("MY TAG","failed");
                Toast.makeText(ShowAllBlock.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

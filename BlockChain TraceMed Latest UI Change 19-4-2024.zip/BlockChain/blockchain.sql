-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 04, 2019 at 11:18 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blockchain`
--

-- --------------------------------------------------------

--
-- Table structure for table `block0`
--

DROP TABLE IF EXISTS `block0`;
CREATE TABLE IF NOT EXISTS `block0` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL,
  `data` text NOT NULL,
  `hash` text NOT NULL,
  `previousHash` text NOT NULL,
  `timeStamp` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `medicine` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `block0`
--

INSERT INTO `block0` (`id`, `mid`, `data`, `hash`, `previousHash`, `timeStamp`) VALUES
(9, 1, 'first block', '3bf81be1cf117d238ad53111d22c1ae82ba6b3fea5b20bd5d9682c678bf35ccb', '0', '2019-03-19 04:36:18'),
(10, 2, 'first block', 'e127dd72a10e7b0f06219449209615de64a9e83f1bca16f0f6d80aadcd59142b', '0', '2019-03-19 10:19:20'),
(11, 3, 'first block', '7189c937e0949419cb5400c989eddde2185cab1f0585f9c2c048292ca9fb4203', '0', '2019-03-19 10:46:37'),
(12, 4, 'first block', '4a74939d02a06b790d65aaf179c1174f6deec036010b216a18d8589bdf9f7d30', '0', '2019-03-19 12:04:40'),
(13, 5, 'first block', 'c357e08e96fbec0bc05f407cd3ddf9cb283c5cf22638f9d15cbc6574e3775f9a', '0', '2019-04-04 11:06:45');

-- --------------------------------------------------------

--
-- Table structure for table `block1`
--

DROP TABLE IF EXISTS `block1`;
CREATE TABLE IF NOT EXISTS `block1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL,
  `data` text NOT NULL,
  `hash` text NOT NULL,
  `previousHash` text NOT NULL,
  `timeStamp` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `medicine1` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `block1`
--

INSERT INTO `block1` (`id`, `mid`, `data`, `hash`, `previousHash`, `timeStamp`) VALUES
(7, 1, 'second block', 'ce9f24993643f6692755d79c5a55fed9103ac15985c126f75007476b6d83cd89', '3bf81be1cf117d238ad53111d22c1ae82ba6b3fea5b20bd5d9682c678bf35ccb', '2019-03-19 04:38:49'),
(8, 2, 'second block', '7311aa2bea188b6426bc7bf765be3d572e9067a8e8f5f37f122690b5c96599f1', 'e127dd72a10e7b0f06219449209615de64a9e83f1bca16f0f6d80aadcd59142b', '2019-03-19 10:22:04'),
(9, 3, 'second block', '5750f27678356f0d72167ebde2a16959bf7603e6f949803ebd1b994b3c47f72c', '7189c937e0949419cb5400c989eddde2185cab1f0585f9c2c048292ca9fb4203', '2019-03-19 10:48:15'),
(10, 4, 'second block', '6ae4c7669364b8e0085762dbea13e196682634e7cbb26322dc0b11df167f8970', '4a74939d02a06b790d65aaf179c1174f6deec036010b216a18d8589bdf9f7d30', '2019-03-19 12:06:52'),
(11, 5, 'second block', 'cc07b53f08f19c167b6d45ddf219ef7f5ed88c688060fde5582030cfdd205379', 'c357e08e96fbec0bc05f407cd3ddf9cb283c5cf22638f9d15cbc6574e3775f9a', '2019-04-04 11:10:20');

-- --------------------------------------------------------

--
-- Table structure for table `block2`
--

DROP TABLE IF EXISTS `block2`;
CREATE TABLE IF NOT EXISTS `block2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL,
  `data` text NOT NULL,
  `hash` text NOT NULL,
  `previousHash` text NOT NULL,
  `timeStamp` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `medicine2` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `block2`
--

INSERT INTO `block2` (`id`, `mid`, `data`, `hash`, `previousHash`, `timeStamp`) VALUES
(1, 1, 'third block', '3f94ec163216aa8730b2761dac89f01080ce120b27ca3f15bff42a8a5650267c', 'ce9f24993643f6692755d79c5a55fed9103ac15985c126f75007476b6d83cd89', '2019-03-19 06:08:29'),
(3, 3, 'third block', 'db6c100591414adc23cc1c6f72051a999dd8e0d10190344a42425a548bc50ff8', '5750f27678356f0d72167ebde2a16959bf7603e6f949803ebd1b994b3c47f72c', '2019-03-19 10:51:32'),
(4, 4, 'third block', '8925e96ef5613b22af5343f27a83504c3824093693af0164e8fc11b48c5dcac6', '6ae4c7669364b8e0085762dbea13e196682634e7cbb26322dc0b11df167f8970', '2019-03-19 13:01:47'),
(5, 5, 'third block', 'fa1edb20444e2c4d3e48cdd3a558f44a5f75832e08aa8a10c838bad0be1de0f3', 'cc07b53f08f19c167b6d45ddf219ef7f5ed88c688060fde5582030cfdd205379', '2019-04-04 11:11:42');

-- --------------------------------------------------------

--
-- Table structure for table `block3`
--

DROP TABLE IF EXISTS `block3`;
CREATE TABLE IF NOT EXISTS `block3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL,
  `data` text NOT NULL,
  `hash` text NOT NULL,
  `previousHash` text NOT NULL,
  `timeStamp` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `medicine3` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `block3`
--

INSERT INTO `block3` (`id`, `mid`, `data`, `hash`, `previousHash`, `timeStamp`) VALUES
(1, 1, 'fourth block', '779a05a3c7cdd5d3691e2ec40f838a2951940629f4401dccbf66ad00af9e2f7c', '3f94ec163216aa8730b2761dac89f01080ce120b27ca3f15bff42a8a5650267c', '2019-03-19 06:10:38'),
(3, 3, 'fourth block', '7eb3f0c15cbf0bbfe0ef9efedc43facb2ef9da2c902f367b04c3a51bd72d2150', 'db6c100591414adc23cc1c6f72051a999dd8e0d10190344a42425a548bc50ff8', '2019-03-19 10:52:26'),
(4, 4, 'fourth block', '41fdc826b2aaaa920b962b2b22e81bc7527120545f2690b94480b8c1d95dd344', '8925e96ef5613b22af5343f27a83504c3824093693af0164e8fc11b48c5dcac6', '2019-03-19 13:20:15'),
(5, 5, 'fourth block', 'e258b815f0ccf7c7085d7766661e854d45489273f67d44eeb008a861aac7fdcc', 'fa1edb20444e2c4d3e48cdd3a558f44a5f75832e08aa8a10c838bad0be1de0f3', '2019-04-04 11:15:30');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE IF NOT EXISTS `company` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cname` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `cname`, `name`, `email`, `mobile`, `password`, `address`) VALUES
(1, 'gsk', 'abc', 'abc@gmail.com', 8954857945, '123', 'nasik');

-- --------------------------------------------------------

--
-- Table structure for table `dealer`
--

DROP TABLE IF EXISTS `dealer`;
CREATE TABLE IF NOT EXISTS `dealer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `cid` int(100) NOT NULL,
  `did` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealer`
--

INSERT INTO `dealer` (`id`, `name`, `email`, `mobile`, `password`, `address`, `cid`, `did`) VALUES
(1, 'pallavi', 'p@gmail.com', 9836547895, '12345', 'nasik', 0, 0),
(2, 'samadhan ', 'samadhan@gmail.com', 8987767856, '12345', 'nasik', 0, 0),
(3, 'rohan tambe', 'rohan@gmail.com', 8987767856, '987', 'nashik kalwan', 1, 2),
(4, '', 'abc@gmail.com', 32153541654, '123', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `distributor`
--

DROP TABLE IF EXISTS `distributor`;
CREATE TABLE IF NOT EXISTS `distributor` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `dname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `cid` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distributor`
--

INSERT INTO `distributor` (`id`, `dname`, `email`, `mobile`, `password`, `address`, `cid`) VALUES
(1, 'sunil', 'sj@gmail.com', 9427767567, '123', 'nasik', 1),
(2, 'dipali', 'dipali@gmail.com', 8987767856, '123', 'nasik', 1),
(3, '', 'abc@gmail.com', 3216548, '123', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `medical`
--

DROP TABLE IF EXISTS `medical`;
CREATE TABLE IF NOT EXISTS `medical` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `medicalname` varchar(100) NOT NULL,
  `ownername` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `licenceno` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cid` int(100) NOT NULL,
  `did` int(100) NOT NULL,
  `dlid` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medical`
--

INSERT INTO `medical` (`id`, `medicalname`, `ownername`, `email`, `mobile`, `licenceno`, `address`, `password`, `cid`, `did`, `dlid`) VALUES
(4, 'nasikmedical', 'samadhan ', 'samadhan@gmail.com', 8987767856, '13243254435', 'nasik', '234', 1, 2, 3),
(5, '', '', 'abc@gmail.com', 6543156871, '', '', '123', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `medicineinfo`
--

DROP TABLE IF EXISTS `medicineinfo`;
CREATE TABLE IF NOT EXISTS `medicineinfo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `batchno` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `quantity` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicineinfo`
--

INSERT INTO `medicineinfo` (`id`, `cid`, `name`, `batchno`, `price`, `quantity`) VALUES
(1, 1, 'DFFHG', 'B123', '12000', 4),
(2, 2, 'PQRS', 'B124', '12000', 4),
(3, 2, 'DDDDDDD', 'B1246546', '300', 4),
(4, 2, 'AAAAA', 'B11111111', '3000', 10),
(5, 2, 'zdfgzdgf', 'Bjhjh', '40', 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `block0`
--
ALTER TABLE `block0`
  ADD CONSTRAINT `medicine` FOREIGN KEY (`mid`) REFERENCES `medicineinfo` (`id`);

--
-- Constraints for table `block1`
--
ALTER TABLE `block1`
  ADD CONSTRAINT `medicine1` FOREIGN KEY (`mid`) REFERENCES `medicineinfo` (`id`);

--
-- Constraints for table `block2`
--
ALTER TABLE `block2`
  ADD CONSTRAINT `medicine2` FOREIGN KEY (`mid`) REFERENCES `block2` (`id`);

--
-- Constraints for table `block3`
--
ALTER TABLE `block3`
  ADD CONSTRAINT `medicine3` FOREIGN KEY (`mid`) REFERENCES `block3` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
